import java.util.Scanner;
public class Assi5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] words = new String[5];
        System.out.println("sogeli 5 strings:");
        for (int i = 0; i < words.length; i++) {
            words[i] = input.nextLine();
        }

        System.out.println("Strings in uppercase:");
        for (String word : words) {
            System.out.println(word.toUpperCase());
        }
    }
}