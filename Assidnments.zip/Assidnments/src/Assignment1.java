import java.util.Scanner;

public class Assignment1 {
    public static double CalculateBMI(double weight, double height) {
        double BMI = weight/(height*height);
        return BMI;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("soo geli weight:");
        int firstInput = input.nextInt();
        System.out.println("soo geli height:");
        double secondInput = input.nextDouble();
        System.out.println("BMI is "+CalculateBMI(firstInput,secondInput));
    }
}
